let phrases = [
  'first',
  'Sword_Knives was here',
  "any computer is a laptop if you're brave enough!",
  'rng!',
  "You've met with a terrible fate, haven't you?",
  'Waiting for something to happen?',
  'suspicious',
  'never gonna give you up / never gonna let you down / never gonna run around and desert you / never gonna make you cry / never gonna say goodbye / never gonna tell a lie and hurt you',
  'getoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyheadgetoutofmyhead',
  "Think you've seen the last of me?",
  'like and subscribe',
  'you cannot kill me in a way that matters',
  'bar abuse!',
  'shoutout to the search bar',
  'minimalism',
  'all rights reserved',
  'total misplay',
  '',
];
//html.style.setProperty("--my-var", rgb(255, 255, 255));

const phraseText = document.querySelector('.phrase');
const phraseIndex = parseInt(Math.random() * phrases.length);
phraseText.textContent = phrases[phraseIndex];

//loaded
/*
body.style.backgroundColor 
*/
