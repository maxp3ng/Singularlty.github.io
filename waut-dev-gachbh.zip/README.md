# singularity

## work in progress

### todo:

### secondary color every refresh

### images

### arg

### end easter egg

### phrase list revamp

### phrases

### fonts
